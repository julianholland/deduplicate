import numpy as np
from abc import ABC, abstractmethod
class DuplicateDetectionAlgorithm(ABC):
    def __init__(
        self,
        tolerance: float,
        input_vector: np.ndarray,
        dataset_array: np.ndarray,
    ) -> None:
        self.tolerance = tolerance
        self.input_vector = input_vector
        self.dataset_array = dataset_array
    
    @abstractmethod
    def duplicate_check(self) -> bool:
        pass
    
    @abstractmethod
    def get_dataset_unique_structures(self):
        pass